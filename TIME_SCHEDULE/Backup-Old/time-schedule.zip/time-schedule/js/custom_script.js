(function($) {
	"use strict";
	// info menu js
	$(".info_menu_icon").click(function(){
		$(".info_nav").slideToggle(300);
	});
  	// date picker
  	 $( ".date_picker" ).datepicker();
  	 	//tabs Menu
	$('.tab_menu .tab_link').on('click', function(){
		$(".tab_content").removeClass("active");
		var tab_data = $(this).attr("data-tab");
		$('.tab_menu .tab_link').removeClass("active");
		$(this).addClass("active");
		$("#"+tab_data).addClass("active");
	});
})(jQuery);

